
package listeners; import org.testng.*; import com.aventstack.extentreports.*; import utilities.*;
public class TestListener implements ITestListener{
 ExtentReports extent=ExtentManager.getReport(); ThreadLocal<ExtentTest> test=new ThreadLocal<>();
 public void onTestStart(ITestResult r){ test.set(extent.createTest(r.getName()));}
 public void onTestSuccess(ITestResult r){ test.get().pass("PASS");}
 public void onTestFailure(ITestResult r){ test.get().fail(r.getThrowable());}
 public void onFinish(ITestContext c){ extent.flush();}
}
