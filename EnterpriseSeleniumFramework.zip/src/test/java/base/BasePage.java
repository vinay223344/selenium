
package base;
import org.openqa.selenium.*; import utilities.WaitUtility;
public class BasePage{
 protected void click(By by){WaitUtility.visible(by,10).click();}
 protected void type(By by,String v){WaitUtility.visible(by,10).sendKeys(v);}
}
