
package base;
import org.testng.annotations.*; import org.openqa.selenium.*; import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager; import utilities.*;
public class BaseTest {
 @BeforeMethod public void setup(){
  WebDriverManager.chromedriver().setup();
  WebDriver d=new ChromeDriver();
  DriverFactory.setDriver(d);
  d.manage().window().maximize();
  d.get(ConfigReader.get("url"));
 }
 @AfterMethod public void tearDown(){
  DriverFactory.getDriver().quit();
  DriverFactory.unload();
 }
}
