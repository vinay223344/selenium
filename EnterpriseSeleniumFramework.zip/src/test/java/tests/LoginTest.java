
package tests;
import org.testng.annotations.Test; import org.testng.Assert;
import base.BaseTest; import pages.LoginPage;
public class LoginTest extends BaseTest{
 @Test public void loginTest(){
  new LoginPage().login("Admin","admin123");
  Assert.assertTrue(true);
 }
}
