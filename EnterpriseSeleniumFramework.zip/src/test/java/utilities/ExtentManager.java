
package utilities; import com.aventstack.extentreports.*; import com.aventstack.extentreports.reporter.ExtentSparkReporter;
public class ExtentManager{
 static ExtentReports extent;
 public static ExtentReports getReport(){
 if(extent==null){ extent=new ExtentReports(); extent.attachReporter(new ExtentSparkReporter("reports/ExtentReport.html"));}
 return extent;
 }
}
