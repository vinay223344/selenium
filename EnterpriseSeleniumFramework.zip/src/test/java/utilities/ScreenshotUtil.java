
package utilities; import org.openqa.selenium.*; import java.io.*; import org.apache.commons.io.FileUtils;
public class ScreenshotUtil{
 public static String capture(String name)throws Exception{
 File src=((TakesScreenshot)DriverFactory.getDriver()).getScreenshotAs(OutputType.FILE);
 String path="screenshots/"+name+".png";
 FileUtils.copyFile(src,new File(path)); return path;
 }
}
