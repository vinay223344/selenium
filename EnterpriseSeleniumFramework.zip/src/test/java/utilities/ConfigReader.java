
package utilities; import java.util.*; import java.io.*;
public class ConfigReader{
 static Properties p=new Properties();
 static{ try{p.load(new FileInputStream("src/test/resources/config.properties"));}catch(Exception e){} }
 public static String get(String key){ return p.getProperty(key);}
}
