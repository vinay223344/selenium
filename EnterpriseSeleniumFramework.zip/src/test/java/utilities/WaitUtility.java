
package utilities; import org.openqa.selenium.*; import org.openqa.selenium.support.ui.*; import java.time.Duration;
public class WaitUtility{
 public static WebElement visible(By by,int sec){
 return new WebDriverWait(DriverFactory.getDriver(),Duration.ofSeconds(sec))
 .until(org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated(by));
 }
}
