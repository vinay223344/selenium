
package pages;
import base.BasePage; import org.openqa.selenium.By;
public class LoginPage extends BasePage{
 By user=By.name("username"); By pass=By.name("password"); By btn=By.xpath("//button[@type='submit']");
 public void login(String u,String p){ type(user,u); type(pass,p); click(btn); }
}
